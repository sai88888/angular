import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { DirectivesComponent } from './directives/directives.component';
import { ChangeTextDirective } from './change-text.directive';
import { CustomPipePipe } from './custom-pipe.pipe';
import { StudentComponent } from './student/student.component';
import { StudentService } from './student.service';
import { EmployeeComponent } from './employee/employee.component';
import { ReactiveApproachComponent } from './reactive-approach/reactive-approach.component';
import { RegisterComponent } from './register/register.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    DirectivesComponent,
    ChangeTextDirective,
    CustomPipePipe,
    StudentComponent,
    EmployeeComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [StudentService],
  bootstrap: [RegisterComponent]
})
export class AppModule { }
