import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators , FormGroup } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  uname :string;
  password :string;
registerForm: FormGroup;
submitted = false;
  constructor( private formbuilder: FormBuilder) {}

  ngOnInit() {

this.registerForm = this.formbuilder.group({

  uname: ['', [ Validators.required, Validators.minLength(4)]],

password: ['', [ Validators.required, Validators.pattern('[A-Z]{5}')]]


});

  }
  get f() {
  return this.registerForm.controls;
  }


  onSubmit(value)
  {
    this.submitted = true;
    if (this.registerForm.invalid)
    {
      return;
    }
    alert("Form Submitted Successfully" + value.uname);
    this.uname = value.uname;
    this.password = value.password;
  }
}
