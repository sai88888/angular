import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  serviceObject: EmployeeService = new EmployeeService();
  listArray: Employee[] = [];
  empId: number;
  empName: string;
  empEmail: string;
  empPhone: number;
  updateChecker: boolean=false;
  constructor() { }

  ngOnInit() {
    this.listArray = this.serviceObject.listEmpService();


  }

 //delete employee method

  delete(i) {
    this.serviceObject.delete(i);
  }
//Editing employee details which are aleready added to employee list

  updateEmployee(i) {
    this.updateChecker = true;
    this.empId = this.listArray[i].id;
    this.empName = this.listArray[i].name;
    this.empEmail = this.listArray[i].email;
    this.empPhone = this.listArray[i].phone;
    }

//To update the form
    
    empUpdate(val) {
    this.listArray = this.serviceObject.empUpdateService(val);
    alert(val.id + '  ' + 'Edited Successfully');
    }
   
}
