import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { Observable } from 'rxjs';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


   static arr: Employee[] = [];

  constructor() { }

  addEmpService(data) {
    let obj;
    obj = new Employee();
    obj.id = data.id;
    obj.name = data.name;
    obj.email = data.email;
    obj.phone = data.phone;
    EmployeeService.arr.push(obj);

    alert(EmployeeService.arr[0].name + '  ' + 'Added Successfully');
  }

  listEmpService(): Employee[] {

    return EmployeeService.arr;
  }

  delete(i) {
    EmployeeService.arr.splice(i, 1);
  }
  empUpdateService(val) {
    for (let i = 0; i < EmployeeService.arr.length; i++) {
    if (val.id === EmployeeService.arr[i].id) {
    EmployeeService.arr[i] = val;
     }
     }
    return EmployeeService.arr;
     }
    
}
