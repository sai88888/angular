import { Directive, ElementRef, HostListener} from '@angular/core';
import { createHostListener } from '../../node_modules/@angular/compiler/src/core';

@Directive({
  selector: '[appChangeText]'
})
export class ChangeTextDirective {

  constructor(private ele:ElementRef) {

ele.nativeElement.innerText = `  hello ......there`;
}
@HostListener('mouseover') onHover(){
  alert('hello');
}

}
