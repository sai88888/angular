import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
uname = 'sai';
@Input()
acceptData: string;

@Output()
obj: EventEmitter<string> = new EventEmitter<string>();
childData: string = "ramu child" ;
  constructor() { }

  sentData() {
    this.obj.emit(this.childData);
  }
  ngOnInit() {
  }

}
