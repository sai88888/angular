import { Component } from '@angular/core';

@Component({
  selector: 's3',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

   parentValue:string = `hi im parent`;


  title = 'myfirst-app';
  id:number=100;
  name:string=`rover`;
  isValid:boolean=true;
  value:any = `any value`;
  image:string = "assets/reigns.png";
  city:string = `chennai`;
  sayHello() {
    alert("hello rer...");
  }
  getData(value) {
alert(value);
  }
}
