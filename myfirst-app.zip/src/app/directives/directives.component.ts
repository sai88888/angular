import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  constructor() { }
isValid :boolean= false;
jsonObj = {aid:'101',ename:'raj',salary:'10000'};
choice=12;
hide:string="javeed";
cities =["delhi","mumbai","hydra"]
  ngOnInit() {
  }

}
