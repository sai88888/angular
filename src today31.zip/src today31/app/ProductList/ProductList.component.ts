import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '../../../node_modules/@angular/router';
import { EmployeeService } from '../employee.service';
import {ProductList} from '../employee';

@Component({
  selector: 'app-login',
  templateUrl: './ProductList.component.html',
  styleUrls: ['./ProductList.component.css']
})
export class ProductListComponent  implements OnInit {
proList: ProductList[] ;

  constructor(private service: EmployeeService) {

  }
  deleteEmployee(i) {
    this.proList.splice( i , 1);
    }
  ngOnInit() {
    this.getAll();
  }
  getAll() {
    this.service.getAll().subscribe(data => this.proList = data);
    }

}
