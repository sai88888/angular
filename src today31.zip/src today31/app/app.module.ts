import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {HttpClientModule, HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ProductListComponent } from './ProductList/ProductList.component';
import { SearchFormComponent } from './SearchForm/SearchForm.component';
import {RouterModule, Routes} from '@angular/router';
import {provideForRootGuard} from '../../node_modules/@angular/router/src/router_module';
import { AppRoutingModule } from './/app-routing.module';
import { EmployeeService } from './employee.service';
const  routes: Routes = [
  {path: '', redirectTo: 'SearchForm', pathMatch: 'full'},
  {path: 'ProductList' , component: ProductListComponent},
  {path: 'SearchForm', component: SearchFormComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    SearchFormComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
