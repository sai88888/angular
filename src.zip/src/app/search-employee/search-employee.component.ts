import { Component, OnInit , Output, EventEmitter } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {Employee} from '../employee';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {
  empList: Employee [];
  SendValue: Employee;

  @Output()
  obj: EventEmitter<Employee> = new EventEmitter<Employee>();



  constructor(private service: EmployeeService) { }

  ngOnInit() {
    this.getAllEmployee();
  }
  getAllEmployee() {
    this.service.getAllEmployees().subscribe(data => this.empList = data);
    }

  addEmployee(addform) {
    this.empList.push(addform.value);
    }
    passData() {
         this.obj.emit(this.SendValue);
    }
    ValueFromComp1(empList1: Employee) {

      j = 0;
      this.empList[j] = empList1;
  }
}
