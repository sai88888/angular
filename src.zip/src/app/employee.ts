



export interface Employee {

eid: number;
ename: string;
email: number;
phone: number;

   }
